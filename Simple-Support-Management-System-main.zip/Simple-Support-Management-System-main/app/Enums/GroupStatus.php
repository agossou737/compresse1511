<?php

namespace App\Enums;

interface GroupStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
