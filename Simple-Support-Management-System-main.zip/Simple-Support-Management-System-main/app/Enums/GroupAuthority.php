<?php

namespace App\Enums;

interface GroupAuthority
{
    const GROUP_PUBLIC  = 5;
    const GROUP_PRIVATE = 10;
}
