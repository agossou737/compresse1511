<?php

namespace App\Enums;

interface FaqStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
