<?php

return [
    'appname'=> 'greensupport',
    'appversion'=> '1.3',
    'authorurl'=> 'https://tracker.greensoftbd.xyz',
];
