<?php

return [
    'add'         => 'Add',
    'edit'        => 'Edit',
    'action'      => 'Action',
    'name'        => 'Name',
    'role'        => 'Role',
    'create_role' => 'Create Role',
    'update_role' => 'Update Role',
    'add_role'    => 'Add Role',
];
