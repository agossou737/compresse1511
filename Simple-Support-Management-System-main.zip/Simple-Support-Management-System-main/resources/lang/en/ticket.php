<?php

return [
    'category'         => 'Category',
    'ticket'         => 'Ticket',
];