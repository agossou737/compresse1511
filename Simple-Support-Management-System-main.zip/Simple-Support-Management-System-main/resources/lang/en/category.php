<?php

return [
    'add'             => 'Add',
    'edit'            => 'Edit',
    'action'          => 'Action',
    'name'            => 'Name',
    'category'        => 'Category',
    'create_category' => 'Create Category',
    'update_category' => 'Update Category',
    'add_category'    => 'Add Category',
];
