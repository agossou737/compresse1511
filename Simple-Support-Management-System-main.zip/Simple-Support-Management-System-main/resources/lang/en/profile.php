<?php

return [
    'profile'       => 'Profile',
    'designation'   => 'Designation',
    'phone'         => 'Phone',
    'email'         => 'Email',
    'edit_profile'  => 'Edit Profile',
    'name'          => 'Name',
    'desingation'   => 'Desingation',
    'email'         => 'Email',
    'phone'         => 'Phone',
    'photo'         => 'Photo',
    'address'       => 'Address',
    'username'      => 'Username',
    'password'      => 'Password',
    'save_changes'  => 'Save Changes',
    'choose_file'   => 'Choose file...',
    'date_of_birth' => 'Date of Birth',
    'joining_date'  => 'Joining Date',
];
