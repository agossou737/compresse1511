<?php

return [
    'add' => 'Add',
    'edit' => 'Edit',
    'action' => 'Action',
    'title' => 'Title',
    'status' => 'Status',
    'faq' => 'Faq',
    'create_faq' => 'Create Faq',
    'update_faq' => 'Update Faq',
    'add_faq' => 'Add Faq',
];
