<?php

use App\Enums\FaqStatus;

return [
    FaqStatus::ACTIVE => 'ACTIVE',
    FaqStatus::INACTIVE    => 'INACTIVE',
];
