<?php

return [
    'conversation' => 'Conversation',
];
