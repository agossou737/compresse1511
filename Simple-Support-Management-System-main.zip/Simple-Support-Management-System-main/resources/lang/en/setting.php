<?php

return [
    'setting' => 'Setting',
    'save_changes' => 'Save Changes',
    'general_setting' => 'General Setting',
    'onesignal_setting' => 'Onesignal Setting',
    'email_setting' => 'Email Setting',
    'general' => 'General',
    'page_setting' => 'Page Setting',
    'google_map_setting' => 'Google Map Setting',
];
