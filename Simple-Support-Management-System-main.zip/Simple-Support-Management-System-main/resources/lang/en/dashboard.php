<?php

return [
    'dashboard'     => 'Dashboard',
    'welcome_to'    => 'Welcome To',
    'total_ticket'  => 'Total Ticket',
    'total_comment' => 'Total Comment',
    'total_user'    => 'Total User',
    'total_message' => 'Total Message',
];
