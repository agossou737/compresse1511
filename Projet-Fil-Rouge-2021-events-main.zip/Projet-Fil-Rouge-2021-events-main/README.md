<h1> Projet Fil Rouge 2021 events </h1>
<img src="/Screenshot/fil-rouge.png"/>
<br>
<hr>
<br>
<h2>Contexte du projet</h2>

Dans le cadre du projet fil rouge chaque apprenant a proposé un cahier des charges pour une idée innovante qui a été validé par sa formatrice.

vous êtes amené à travailler sur le cahier des charges approprié à votre contexte (voir le drive en PJ)

toute en respectant les instructions suivantes:

utiliser le diagramme de Gantt pour planifier votre travail.

Réaliser une maquette et un prototype (web/mobile) simulant votre Projet.

Réaliser une charte graphique pour votre Projet.

Les pages web doivent être responsive et respecter le prototype, la charte graphique et l’UX/UI

Vous êtes amenés à être créatif en proposant du contenu adapté (texte correcte /et images).

les champs de vos interfaces de votre site doivent respecter les contraintes de validation ex: - le champs numéro téléphone ne doit pas accepter les caractères. vérifier les champs : CIN, Email,....

la platform doit permettre l'authentification et la gestion des multi-Profil (ex: Admin, utilisateur, Client..)

Réaliser la conception et la modélisation avec l’UML

Diagramme de cas d’utilisation

Diagramme de séquence

Diagramme de classes

la platform doit offrir les fonctionnalités : Creat,Read,Update,Delete,Search,...

vous pouvez utiliser les API ou plugin pour améliorer les Fonctionnalités de votre site(ex: Calendrier, Video, Chat,..)

<h2>Choix Technologique : </h2>

Front-End : HTML5, CSS3,SASS, javascript, Bootstrap, VueJS,...

Base de donnée : MySql

Backend : PHP/POO/MVC ou utiliser le framework Laravel

Bonne chance et bon courage à vous tous.
<br>
<hr>
<br>
<img src="/Screenshot/Home.png"/>
<br>
<hr>
<br>
<img src="/Screenshot/Events_visiteur.png"/>
<br>
<hr>
<br>
<img src="/Screenshot/Events_visiteur.png"/>
<br>
<hr>
<br>
<img src="/Screenshot/Sing up.png"/>
<br>
<hr>
<br>
<img src="/Screenshot/Event.png"/>

