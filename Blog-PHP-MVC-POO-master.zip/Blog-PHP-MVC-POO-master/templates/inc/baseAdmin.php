<link href="../public/css/freelancer.css">


<nav id="mainNav" class="navbar navbar-default  navbar-fixed-top navbar-top navbar-custom">
    <div class="container">

        <div class="navbar-header ">
            <button type="button" class="navbar-toggle" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="../public/index.php">Sacha Durand</a>
        </div>


        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="hidden">
                    <a href="#page-top"></a>
                </li>
                <li class=" navli ">
                    <a href="index.php?route=back-office">Acceuil</a>
                </li>
                <li class=" navli ">
                    <a href="index.php?route=adminarticle">Gerer les articles</a>
                </li>
                <li class="">
                    <a href="index.php?route=admincommentaire">Gerer les commentaires</a>
                </li>
                <li class="">
                    <a href="index.php?route=admindroit">Gerer les droits</a>
                </li>


            </ul>
        </div>

    </div>

</nav>
</br>
</br>
</br>
</br>
