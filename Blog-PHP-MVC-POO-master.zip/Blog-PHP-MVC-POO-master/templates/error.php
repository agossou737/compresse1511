<?php
$this->title = "Error";
echo '<h1> ERROR </h1>';
echo ' There are error, please wait and press F5 <br/><br/>';
echo '<a href="../public">Go to home </a>';

echo '<br/>';
