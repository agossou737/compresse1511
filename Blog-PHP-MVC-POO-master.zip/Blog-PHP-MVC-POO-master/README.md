
This website is a open-source blog/portfolio with a MVC ( Model View Controller ) architecture. Used for present project & blogpost. The website have a 
administration zone where you can manage a article, comment, member.... 

This site has been programmed in native PHP code without framework or library other than Bootstrap and javacript
The architecture uses object-oriented programming. You will see the associated shema in the "UML" folder. 
This folder summarizes the objectives and architecture of the site. 

For use this project... 
1. Clone this project in your repository or folder
2. Import a SQL Database from SQL folder
3. Import user in database from SQL folder
4. Change connexion information in dev.php (config folder)

This website is available in "sachadurand.fr/Projet5"
License : Free

Suggestion and / or comments? Please create issues for this

Standard : 
 1. PSR2 ( https://www.php-fig.org/psr/psr-2/ ) 
 2. silver medal in sensolabs ( https://insight.symfony.com )




   
