<?php
const HOST = 'localhost';
const DB_NAME = 'bdd_projet5';
const CHARSET = 'utf8';
const DB_HOST = 'mysql:host=' . HOST . ';dbname=' . DB_NAME . ';charset=' . CHARSET;
const DB_USER = 'root';
const DB_PASS = '';


