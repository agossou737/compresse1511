<?php

class Prueba{
    public $nombre;
}

echo json_encode('todo listo');