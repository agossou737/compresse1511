<?php


echo json_encode('todo ok');