<?php
 
 //ce fichier est fait pour inclure tous les fichier sans le faire en index.php
 include "../app/core/config.php";
 include "../app/core/controller.php";
 include "../app/core/functions.php";
 include "../app/core/database.php";
 include "../app/core/setting.class.php";
 include "../app/core/app.php";
